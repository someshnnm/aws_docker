### Expected behavior

### Actual behavior

### Information

  - Full output of the diagnostics from "docker-diagnose" ran from one of the instance
  - A reproducible case if this is a bug, Dockerfiles FTW
  - Page URL if this is a docs issue or the name of a man page

### Steps to reproduce the behavior

  1. ...
  2. ...
